# VariantesApp (APK automático)

Este repositorio está listo para que **GitHub** genere tu **APK** automáticamente, sin tocar Android Studio.

## Pasos (muy fáciles)
1. Crea una cuenta en **GitHub** (gratis).
2. Entra a github.com → arriba a la derecha **+** → **New repository** → ponle nombre **VariantesApp** → Create repository.
3. Descarga este ZIP y súbelo tal cual:
   - Clic en **Add file** → **Upload files** → Arrastra todo el contenido de esta carpeta (o el ZIP descomprimido) y pulsa **Commit**.
4. Ve a la pestaña **Actions** del repositorio.
5. En la izquierda elige **Android APK (One-Click)** → pulsa **Run workflow** (o haz un commit a `main`).
6. Espera a que termine y entra al job → sección **Artifacts** → descarga **VariantesApp-debug-apk**. ¡Listo!

> Nota: Este flujo genera un **APK de debug** (para instalar y probar). Para publicar en Play Store necesitarás un **APK/AAB firmado**, puedo agregarte el paso de firma si me pasas un keystore (o te genero uno).

## ¿Qué hace la app?
- Crea productos.
- Añade variantes (SKU, precio, stock).
- Guarda datos localmente en el teléfono.

Si quieres que agregue **exportación a CSV**, **imágenes** o **sincronización en la nube**, avísame y lo integro en este repo.
