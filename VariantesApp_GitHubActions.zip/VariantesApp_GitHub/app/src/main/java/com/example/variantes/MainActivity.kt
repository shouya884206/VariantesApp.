package com.example.variantes

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// ------------ Modelo de datos ------------
data class Variant(
    var sku: String = "",
    var nombre: String = "",
    var precio: Double = 0.0,
    var stock: Int = 0
)

data class Product(
    var id: Long = System.currentTimeMillis(),
    var nombre: String = "",
    var descripcion: String = "",
    var variantes: MutableList<Variant> = mutableListOf()
)

// ------------ Persistencia simple (SharedPreferences + JSON) ------------
private const val PREFS = "inventario_prefs"
private const val KEY_DATA = "productos_json"

class Repo(private val context: Context) {
    private val gson = Gson()

    fun cargar(): MutableList<Product> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_DATA, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Product>>() {}.type
        return gson.fromJson(json, type) ?: mutableListOf()
    }

    fun guardar(lista: List<Product>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = gson.toJson(lista)
        prefs.edit().putString(KEY_DATA, json).apply()
    }
}

// ------------ Activity ------------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = Repo(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                InventarioApp(repo)
            }
        }
    }
}

// ------------ App Compose ------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventarioApp(repo: Repo) {
    var productos by remember { mutableStateOf(repo.cargar()) }
    var mostrandoEditor by remember { mutableStateOf(false) }
    var productoEditando by remember { mutableStateOf<Product?>(null) }

    fun guardarCambios() {
        repo.guardar(productos)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Inventario con Variantes") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                productoEditando = Product()
                mostrandoEditor = true
            }) { Text("+") }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            if (mostrandoEditor) {
                EditorProducto(
                    initial = productoEditando ?: Product(),
                    onGuardar = { p ->
                        val idx = productos.indexOfFirst { it.id == p.id }
                        if (idx >= 0) productos[idx] = p else productos.add(0, p)
                        guardarCambios()
                        mostrandoEditor = false
                    },
                    onCancelar = { mostrandoEditor = false }
                )
            } else {
                ListaProductos(
                    productos = productos,
                    onEditar = { p ->
                        productoEditando = p.copy(
                            variantes = p.variantes.map { it.copy() }.toMutableList()
                        )
                        mostrandoEditor = true
                    },
                    onEliminar = { p ->
                        productos = productos.filter { it.id != p.id }.toMutableList()
                        guardarCambios()
                    }
                )
            }
        }
    }
}

@Composable
fun ListaProductos(
    productos: List<Product>,
    onEditar: (Product) -> Unit,
    onEliminar: (Product) -> Unit
) {
    if (productos.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Aún no hay productos. Toca el + para crear uno.")
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(productos, key = { it.id }) { p ->
            ElevatedCard(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(p.nombre, style = MaterialTheme.typography.titleMedium)
                    if (p.descripcion.isNotBlank()) Text(p.descripcion)
                    Spacer(Modifier.height(8.dp))
                    Text("Variantes: ${p.variantes.size}")
                    p.variantes.forEach { v ->
                        Text("• ${v.nombre} (SKU: ${v.sku}) — Precio: ${v.precio} — Stock: ${v.stock}")
                    }
                    Spacer(Modifier.height(12.dp))
                    Row {
                        Button(onClick = { onEditar(p) }) { Text("Editar") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { onEliminar(p) }) { Text("Eliminar") }
                    }
                }
            }
        }
    }
}

@Composable
fun EditorProducto(
    initial: Product,
    onGuardar: (Product) -> Unit,
    onCancelar: () -> Unit
) {
    var nombre by remember { mutableStateOf(initial.nombre) }
    var descripcion by remember { mutableStateOf(initial.descripcion) }
    var variantes by remember { mutableStateOf(initial.variantes) }

    fun agregarVariante() { variantes.add(Variant()) }

    fun actualizarVariante(index: Int, nueva: Variant) {
        variantes[index] = nueva
    }

    fun eliminarVariante(index: Int) {
        variantes.removeAt(index)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre del producto") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = descripcion,
            onValueChange = { descripcion = it },
            label = { Text("Descripción") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Text("Variantes", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(variantes.size) { idx ->
                VarianteItem(
                    variante = variantes[idx],
                    onChange = { actualizarVariante(idx, it) },
                    onRemove = { eliminarVariante(idx) }
                )
                Spacer(Modifier.height(8.dp))
            }
        }

        Row {
            OutlinedButton(onClick = { agregarVariante() }) { Text("Añadir variante") }
            Spacer(Modifier.width(12.dp))
            Button(
                enabled = nombre.isNotBlank(),
                onClick = {
                    onGuardar(
                        Product(
                            id = initial.id,
                            nombre = nombre,
                            descripcion = descripcion,
                            variantes = variantes
                        )
                    )
                }
            ) { Text("Guardar producto") }
            Spacer(Modifier.width(12.dp))
            TextButton(onClick = onCancelar) { Text("Cancelar") }
        }
    }
}

@Composable
fun VarianteItem(
    variante: Variant,
    onChange: (Variant) -> Unit,
    onRemove: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            OutlinedTextField(
                value = variante.nombre,
                onValueChange = { onChange(variante.copy(nombre = it)) },
                label = { Text("Nombre de la variante (p.ej. Talla M - Rojo)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = variante.sku,
                onValueChange = { onChange(variante.copy(sku = it)) },
                label = { Text("SKU") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = if (variante.precio == 0.0) "" else variante.precio.toString(),
                onValueChange = { txt ->
                    val v = txt.toDoubleOrNull() ?: 0.0
                    onChange(variante.copy(precio = v))
                },
                label = { Text("Precio") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = if (variante.stock == 0) "" else variante.stock.toString(),
                onValueChange = { txt ->
                    val s = txt.toIntOrNull() ?: 0
                    onChange(variante.copy(stock = s))
                },
                label = { Text("Stock") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row {
                TextButton(onClick = onRemove) { Text("Eliminar variante") }
            }
        }
    }
}
